import Date
import Lists

def borrow():
    IsBorrowed=False
    #Using loops
    while(True):
        # input values
        FirstName=input("Please Enter the first name of the borrower: ")
        LastName=input("Please Enter the last name of the borrower: ")
        print("\n")
        break
    # creating a txt file on borrower
    record="Borrowed by "+FirstName+".txt"
    file=open(record,"w+")
    file.write("\t\t\tDetails of the Borrower and the book borrowed\n")
    file.write("Borrowed by: "+FirstName+ " "+LastName+ "\n")
    file.write("Date and Time of borrowing: "+Date.datetime()+"\n\n")
    file.write("\t\t S.N. \t\t Name of the Book \t\t Author\n")
    file.close()
    while IsBorrowed==False:
        print("Enter an number from below to borrow a book: ")
        for i in range(len(Lists.Books)):
            print("To borrow", Lists.Books[i],"Enter the number",i)   
        try:
            num=int(input("Enter the number:"))
            try:
                # writing the borrowed book to txt file
                if(int(Lists.Quantity[num])>0):
                    print("The book is available")
                    file=open(record,"a")
                    file.write("\t\t 1. \t\t"+Lists.Books[num]+"\t\t "+Lists.Author[num]+"\n")
                    file.close()
                    Lists.Quantity[num]=int(Lists.Quantity[num])-1
                    file=open("Books.txt","w+")
                    for i in range(4):
                        file.write(Lists.Books[i]+","+Lists.Author[i]+","+str(Lists.Quantity[i])+","+"$"+Lists.Price[i]+"\n")
                    file.close()

                    borrowmultiple=True
                    counter=1
                    while borrowmultiple==True:
                        # processing multiple borrowingg
                        Ask=input("Do you wish to borrow another book? Type y for yes and n for no ").lower()
                        if(Ask=="y"):
                            counter=counter+1
                            print("Enter the books corresponding number to borrow ti: ")
                            for i in range(len(Lists.Books)):
                                print("If your book choice is ", Lists.Books[i],"Enter the number",i) 
                            try:
                                check=int(input("Please Enter the number:"))
                                try:
                                    if(int(Lists.Quantity[check])>0):
                                        print("This book is available")
                                        file=open(record,"a")
                                        file.write("\t\t "+str(counter)+"."+"\t\t"+Lists.Books[check]+"\t\t "+Lists.Author[check]+"\n")
                                        file.close()
                                        Lists.Quantity[check]=int(Lists.Quantity[check])-1
                                        file=open("Books.txt","w+")
                                        for i in range(4):
                                            file.write(Lists.Books[i]+","+Lists.Author[i]+","+str(Lists.Quantity[i])+","+"$"+Lists.Price[i]+"\n")
                                        file.close()
                                    else:
                                        borrowmultiple=False
                                        break
                                    # tracing and warning for invalid data input and errors.
                                except IndexError:
                                    print("Choose the books according to their number")
                            except ValueError:
                                print("Choose as suggested")
                        else:
                            print("Mind that returning date is 10 days from the date of borrow and fine will be levid for late return of books. Thank you for borrowing books from us.\n\n")
                            borrowmultiple=False
                            IsBorrowed=True
            except IndexError:
                print("Choose the books according to their number")
        except ValueError:
            print("Please Choose within the given options only")
        
