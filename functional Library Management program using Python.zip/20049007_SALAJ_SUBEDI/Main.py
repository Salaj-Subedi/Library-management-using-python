import BorrowBook
import ReturnBook
import Lists
import Date

def main():
    looping=True 
    while(looping==True):
        #display choice
        print("\n")
        print("-------------Welcome to our Library-----------")
        print(" Please Enter  "+"1"+"  to Display the books")
        print(" Please Enter  "+"2"+"  to Borrow our books")
        print(" Please Enter  "+"3"+"  to Return a borrowed book")
        print(" To Exit, Please  Enter  "+"4")
        print("---------------------------------------------------------")
        # try block to look for errors in 
        try:
            ##Asking  input
            id=int(input("Provide your input here:- "))
            #Using the if and else to process further.
            if(id==1):
                #opening a text file and printing its content
                print("\n")
                print("books here are displayed in  NAME , AUTHOR , QUANTITY , BORROWING PRICE format")
                file=open("Books.txt","r")
                read=file.read()
                print(read)
                file.close()
            elif(id==2):
                #Calling Lists and BorrowBook module
                Lists.lists()
                BorrowBook.borrow()
            elif(id==3):
                #Calling Lists and ReturnBook module
                Lists.lists()
                ReturnBook.Return()
            elif(id==4):
                #Displaying 
                print("Thank you for choosing us!")
                break
            else:
                # else block
                print("Please enter a number from the given choices.")
        except ValueError:
            #except block if error occurs
            print("Invalid! only numeric data that is within the given choices are accepted.")
main()




