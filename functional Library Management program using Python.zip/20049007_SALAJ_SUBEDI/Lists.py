Books = []
Author = []
Quantity = []
Price = []
def lists():
    file=open("Books.txt","r")
    read=file.readlines()
    read=[a.strip("\n") for a in read]
    for i in range(len(read)):
        a=0
        for j in read[i].split(","):
            if(a==0):
                Books.append(j)
            elif(a==1):
                Author.append(j)
            elif(a==2):
                Quantity.append(j)
            elif(a==3):
                Price.append(j.strip("$"))
            a=a+1

    



