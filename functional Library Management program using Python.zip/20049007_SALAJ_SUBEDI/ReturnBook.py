import Lists
import Date

def Return():

    #input value
    Name=input("Enter the name of the borrower:")
    text="Borrowed by "+Name+".txt"
    # try block  for errors
    try:
        file=open(text,"r")#read  text file
        line=file.readlines()
        line=[text.strip("$") for text in line]#Removing the $ using strip keyword
        file.close()
        file=open(text,"r")
        info=file.read()
        print(info)
    #Using the except block for error
    except:
        print("The name of the borrower does not match")
        Return()
    store="Returner "+Name+".txt"
    file=open(store,"w+")#read and write text file
    print("\n")
    print("\n")
    file.write("\t\t\tDetails of the Returned Book \n\n")
    file.write("Date and Time of Returning: "+Date.datetime()+"\n\n")
    file.write("Returned by: "+Name+"\n")
    #Using  function of Date module
    
    file.write("\t\tS.N.\t\t Name of the Book\t\tCost\n")
    file.close()

    cost=0.0
    #for loop to add  in the text file
    for i in range(4):
        if Lists.Books[i] in info:
            file=open(store,"a")# text file in append mode
            #Lists module to write inside the text file
            file.write("\t\t"+str(i+1)+"\t\t"+Lists.Books[i]+"\t\t\t$"+Lists.Price[i]+"\n")
            file.close()
            Lists.Quantity[i]=int(Lists.Quantity[i])+1
            cost=cost+float(Lists.Price[i])
            
            
    print("\t\t Total Price= "+"$"+str(cost)+"\n\n")
    check=input("Is the book being given back late (if you return the book after 10 days its late)? Type y for yes and n for no: ").lower()
    #if else function
    if check=="y":
        days=int(input("How manys days is the book being given back late?"))
        if days>=1:
            print("You have returned the book late. Therefore, you have to pay a fine.")
            fine=2*days
            file=open(store,"a")
            file.write("\t\tFine: $"+str(fine)+"\n")
            cost=cost+fine
        print("Total after fine: $"+str(cost))
    #Opening the text file in read and write mode
    file=open("Books.txt","w+")
    #Using for loop to change the values in text file
    for i in range(4):
        file.write(Lists.Books[i]+","+Lists.Author[i]+","+str(Lists.Quantity[i])+","+"$"+Lists.Price[i]+"\n")
    file.close()

