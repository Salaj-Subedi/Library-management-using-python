def datetime():
    import datetime
    dandt=datetime.datetime.now()
    #print("Date and Time:",dandt)
    return str(dandt)


