str=input("Enter string of numbers: ")
l=[]
for i in range(len(str)):
    l.append(int(str[i]))
print("The list of numbers is: ",l)
max=l[0]
min=l[0]
sum=0
for i in range(len(str)):
    sum+=l[i]
    if(max<l[i]):
        max=l[i]
    if(min>l[i]):
        min=l[i]
print("The sum of the numbers is: ",sum)
print("The maximum number is: ",max)
print("The minumum number is: ",min)
