L = [9,2,1,7,5]
i = 1
#loop while i is less than the no.of elements in list L
while i< len(L):
      key = L[i]
      j = i - 1#set j to be i -1

      while j >= 0 and key < L[j]:  #initialize and loop while j is less than or equal to 0
            L[j +1] = L[j]
            j = j - 1#reducing value of J to terminate program when needed

      L[j + 1] = key#placing all the updated elements on the list.
      i = i + 1#adding value of i by 1 for continuation of loop

print(L)
