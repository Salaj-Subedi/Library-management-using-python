

first=input("please provide the first string :")
second=input("please provide the second string:")
a=list(set(first)&set(second))
print("The common letters between the two string inputs are:")
print(a)



#using function
def words(firstWord,secondWord):
    commonLetters =(set(firstWord).intersection(set(secondWord)))
    return commonLetters

word1 = input("Enter the first word: ")
word2 = input("Enter the second word: ")
print("Common letters between two words:", list(words(word1,word2)))
